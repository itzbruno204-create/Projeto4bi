document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('nav a');
    const sections = document.querySelectorAll('.page-section');
    const btnLinguagens = document.querySelector('.trabalhos-por-area-grid .area-saber-card:nth-child(1) .btn-ver-trabalhos');

    function showSection(targetId) {
        sections.forEach(section => {
            section.classList.remove('active');
        });
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            targetSection.classList.add('active');
            window.scrollTo(0, 0); 
        }
    }

    // Lógica para navegação SPA (menu principal)
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // Só bloqueia se tiver data-target (SPA)
if (e.currentTarget.hasAttribute('data-target')) {
    e.preventDefault();
}

            const targetId = e.currentTarget.getAttribute('data-target');
            // Se o link tiver um data-target (navegação SPA)
            if (targetId) {
                showSection(targetId);
            } 
            // Se for um link externo (como os links no linguagens.html)
            else if (e.currentTarget.getAttribute('href').startsWith('index.html')) {
                window.location.href = e.currentTarget.getAttribute('href');
            }
        });
    });

    // Lógica para o botão "Ver trabalhos" de Linguagens (redireciona para o novo arquivo HTML)
    if (btnLinguagens) {
        btnLinguagens.addEventListener('click', () => {
            window.location.href = 'linguagens.html';
        });
    }


    // Lida com a seção inicial (carregamento ou hash na URL)
    const initialHash = window.location.hash.substring(1);
    // Esta lógica é executada apenas em index.html
    if (document.getElementById('sobre-sec')) {
        if (initialHash && document.getElementById(initialHash)) {
            showSection(initialHash);
        } else {
            showSection('sobre-sec'); 
        }
    }
});